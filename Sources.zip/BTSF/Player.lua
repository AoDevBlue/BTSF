local Player = {
	image = love.graphics.newImage("Player.png"),
	impulseValue = 100,
}
Player.__index = Player

function Player.new(x, y)
	local self = setmetatable({}, Player)
  	self.body = love.physics.newBody(world, x, y, "dynamic")
	self.shape = love.physics.newRectangleShape(self.image:getWidth(),self.image:getHeight())
	self.fixture = love.physics.newFixture(self.body, self.shape, 0)
	self.fixture:setRestitution(0.1)
	self.fixture:setCategory(2)

	return self
end

function Player:update(dt)

	if love.keyboard.isDown("up") or love.keyboard.isDown("w") then
		self.body:applyLinearImpulse(0,-self.impulseValue)
	end
	if love.keyboard.isDown("down") or love.keyboard.isDown("s") then
		self.body:applyLinearImpulse(0,self.impulseValue)
	end
	if love.keyboard.isDown("left") or love.keyboard.isDown("a") then
		self.body:applyLinearImpulse(-self.impulseValue,0)
	end
	if love.keyboard.isDown("right") or love.keyboard.isDown("d") then
		self.body:applyLinearImpulse(self.impulseValue,0)
	end
	
	local vx,vy
	vx,vy = self.body:getLinearVelocity()
	self.body:setLinearVelocity((1-10*dt)*vx,(1-10*dt)*vy)
end

function Player:draw()
	love.graphics.setColor(255, 255, 255, 255)
	local x,y
	x,y = self.body:getPosition()
	love.graphics.draw(self.image,x-self.image:getWidth()/2,y-self.image:getHeight()/2)
end

function Player:destroy()
	self.fixture:destroy()
	self.body:destroy()
end

return Player