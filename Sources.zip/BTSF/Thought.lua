local Thought = {
	image = nil,
	impulseValue = 10,
	alive = 1,
	goal_x = 400,
	goal_y = 300,
	step = 0,
	isSwear = 1,
}
Thought.__index = Thought

function Thought.new(isSwear)
	local self = setmetatable({}, Thought)
	local nbSpawn
	
	if isSwear == 1 then
		self.image = love.graphics.newImage("Swear.png")
		self.isSwear = 1
	else
		self.image = love.graphics.newImage("NonSwear.png")
		self.isSwear = 0
	end
	
	nbSpawn = math.random(1,3)
	if nbSpawn == 1 then
  		self.body = love.physics.newBody(world,0-self.image:getWidth()/2,0-self.image:getHeight()/2, "dynamic")
  	elseif nbSpawn == 2 then
  		self.body = love.physics.newBody(world,0-self.image:getWidth()/2,600+self.image:getHeight()/2, "dynamic")
  	else
  		self.body = love.physics.newBody(world, 800+self.image:getWidth()/2,0-self.image:getHeight()/2, "dynamic")
  	end
	self.shape = love.physics.newRectangleShape(self.image:getWidth(),self.image:getHeight())
	self.fixture = love.physics.newFixture(self.body, self.shape, 0)
	self.fixture:setRestitution(2)
	self.fixture:setCategory(3)
	self.fixture:setMask(1)

	return self
end

function Thought:update(dt)
	local x,y,xBoundUp,yBoundUp,xBoundDown,yBoundDown,xBoundLeft,yBoundRight,xBoundRight,yBoundRight,dir_x,dir_y
	x,y = self.body:getPosition()
	xBoundUp,yBoundUp = bounds.up.body:getWorldCenter()
	xBoundDown,yBoundDown = bounds.down.body:getWorldCenter()
	xBoundLeft,yBoundLeft = bounds.left.body:getWorldCenter()
	xBoundRight,yBoundRight = bounds.right.body:getWorldCenter()
	
	if x > love.window:getWidth() and y > love.window:getHeight() then
		self.alive = 0
		self.fixture:destroy()
		self.body:destroy()
		
		swearOMeter:addToMax(1)
		if self.isSwear == 1 then
			swearOMeter:add(1)
			badAnswersNumber = badAnswersNumber + 1
			swearPassed:play()
		else
			goodAnswersNumber = goodAnswersNumber + 1
			nonSwearPassed:play()
		end
	elseif bounds.up.shape:testPoint(xBoundUp,yBoundUp,0, x, y)
		or bounds.down.shape:testPoint(xBoundDown,yBoundDown,0, x, y)
		or bounds.left.shape:testPoint(xBoundLeft,yBoundLeft,0, x, y)
		or bounds.right.shape:testPoint(xBoundRight,yBoundRight,0, x, y)
		then
		self.alive = 0
		self.fixture:destroy()
		self.body:destroy()
		swear_die:play()
	else
		if math.abs(x-self.goal_x) < 80 and math.abs(y-self.goal_y) < 80 then
			if self.step == 0 then
				self.goal_x = 660
				self.goal_y = 470
				self.step = 1
			else
				self.goal_x = 950
				self.goal_y = 750
			end
		end
		
		dir_x,dir_y = self:getDirectionVector()
		self.body:applyLinearImpulse(self.impulseValue*dir_x,self.impulseValue*dir_y)
		
		local action = math.random(0,6)
		if action == 1 then -- left
			self.body:applyLinearImpulse(-self.impulseValue,0)
		end
		if action == 2 then -- right
			self.body:applyLinearImpulse(self.impulseValue,0)
		end
		if action == 3 then -- up
			self.body:applyLinearImpulse(0,-self.impulseValue)
		end
		if action == 4 then -- down
			self.body:applyLinearImpulse(0,self.impulseValue)
		end
		
		local vx,vy
		vx,vy = self.body:getLinearVelocity()
		self.body:setLinearVelocity((1-5*dt)*vx,(1-5*dt)*vy)
	end
end

function Thought:getDirectionVector()
	local x,y, dir_x, dir_y, norm
	x,y = self.body:getPosition()
	dir_x = self.goal_x - x
	dir_y = self.goal_y - y
	if dir_x ~= 0 or dir_y ~= 0 then
		norm = math.sqrt(dir_x^2 + dir_y^2)
		dir_x = dir_x / norm
		dir_y = dir_y / norm
	end
	return dir_x,dir_y
end

function Thought:destroy()
	self.alive = 0
	self.fixture:destroy()
	self.body:destroy()
end

function Thought:draw()
	love.graphics.setColor(255, 255, 255, 255)
	local x,y,xd,yd
	x,y = self.body:getPosition()
	love.graphics.draw(self.image,x-self.image:getWidth()/2,y-self.image:getHeight()/2)
	
end

return Thought