local HUDBar = {
	x = 0,
	y = 0,
	w1 = 0,
	h1 = 0,
	w2 = 0,
	h2 = 0,
	filling = 0,  -- What a FILLING
	maxValue = 0,
	color1 = {},
	color2 = {},
	color3 = {},
	message = "",
}
HUDBar.__index = HUDBar

function HUDBar.new(x,y,w1,h1,w2,h2,maxValue,filling,color1,color2,color3,message)
	local self = setmetatable({}, HUDBar)
	self.x = x
	self.y = y
	self.h1 = h1
	self.w1 = w1
	self.h2 = h2
	self.w2 = w2
	self.filling = filling
	self.maxValue = maxValue
	self.color1 = color1
	self.color2 = color2
	self.color3 = color3
	self.message = message
	return self
end

function HUDBar:add(value)
	if self.filling + value <= self.maxValue then
		self.filling =  self.filling + value
	else
		self.filling = self.maxValue
	end
end

function HUDBar:substract(value)
	if self.filling - value >= 0 then
		self.filling =  self.filling - value
	else
		self.filling = 0
	end
end

function HUDBar:addToMax(value)
	self.maxValue = self.maxValue + value
end

function HUDBar:draw()
	love.graphics.setColor(self.color1)
	love.graphics.rectangle("fill", self.x - self.w1/2, self.y - self.h1/2, self.w1, self.h1 )
	
	love.graphics.setColor(self.color2)
	love.graphics.rectangle("fill", self.x - self.w2/2, self.y - self.h2/2, self.w2, self.h2 )
	
	love.graphics.setColor(self.color3)
	love.graphics.rectangle("fill", self.x - self.w2/2, self.y - self.h2/2, self.w2 * self.filling/self.maxValue, self.h2 )
	
	local font, width, height
	font = love.graphics.getFont()
	width = font:getWidth(self.message)
	height = font:getHeight()
	
	love.graphics.setColor(255,255,255,255)
	love.graphics.print(self.message,self.x-width/2,self.y-self.h1/2-height)
end

return HUDBar