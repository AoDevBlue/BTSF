local Player = require 'Player'
local Thought = require 'Thought'
local HUDBar = require 'HUDBar'
local Conversation = require 'Conversation'
TextBase = require 'TextBase'

-- Constants
background = love.graphics.newImage("background.png")
smile = love.graphics.newImage("smile.png")
frown = love.graphics.newImage("frown.png")
menu = love.graphics.newImage("menu.png")
tutorial = love.graphics.newImage("story-tutorial.png")
border = love.graphics.newImage("border.png")
font = love.graphics.newFont("visitor1.ttf", 16)
love.graphics.setFont(font)
lightBlue = {134, 210, 238, 255}
darkBlue = {35,92,115,255}
darkRed = {153,37,37,255}
white = {255,255,255,255}
normalBlue = {65,176,217,255}
red = {255,62,62,255}
green = {106,204,10,255}

-- Sounds
swear_die = love.audio.newSource("swear_die.wav", "static")
swear_die:setVolume(0.6)
changeSelect = love.audio.newSource("changeSelect.wav","static")
changeSelect:setVolume(0.4)
swearPassed = love.audio.newSource("swearPassed.wav","static")
swearPassed:setVolume(0.2)
nonSwearPassed = love.audio.newSource("nonSwearPassed.wav","static")
nonSwearPassed:setVolume(0.2)
goodAnswerSound = love.audio.newSource("goodAnswer.wav","static")
goodAnswerSound:setVolume(0.5)
badAnswerSound = love.audio.newSource("BadAnswer.wav","static")
badAnswerSound:setVolume(0.5)

-- Music
music = love.audio.newSource("PersonalFury.mp3")
music:setLooping(true)
music:setVolume(0.4)
music:play()



-- Global Variables
player = nil
bounds = {}
swearOMeter = nil
timeLeft = nil
conversation = nil
goodAnswersNumber = 0
badAnswersNumber = 0

-- Local Variables
local swears = {}
local nonSwears = {}
local indexConversation = 1
local panel = 0
local nbSwearsMax = 2
local nbNonSwearsMax = 5
local nbSwears = 0
local nbNonSwears = 0
local timeCountSwear = 0
local timeCountNonSwear = 0
local timeNextNonSwear = 0
local timeCountMessage = 0
local swearsInARow = 0
local soundOn = 1
local HardMode = 0
local incrementGoodAnswer = 0.75
local incrementBadAnswer = 2
local keyReleased = 1

-- Constants
local maxTimeMessage = 5
local maxTimeConversation = 15
local maxTimeGame = 25
local nbSpawnMax = 2
local delayBeforeSpawn = 2


function love.load()
	love.window.setMode(800, 600)
	love.window.setTitle("Behind the Smile Face")
	world = love.physics.newWorld(0, 0, true)
	love.physics.setMeter(20)
	
	-- Circles matching the background
	bounds.down = {}
	bounds.down.body = love.physics.newBody(world, 400, 600+370)
	bounds.down.shape = love.physics.newCircleShape(500)
	bounds.down.fixture = love.physics.newFixture(bounds.down.body, bounds.down.shape)
	bounds.down.fixture:setCategory(1)
	
	bounds.up = {}
	bounds.up.body = love.physics.newBody(world, 400, -370)
	bounds.up.shape = love.physics.newCircleShape(500)
	bounds.up.fixture = love.physics.newFixture(bounds.up.body, bounds.up.shape)
	bounds.up.fixture:setCategory(1)
	
	bounds.left = {}
	bounds.left.body = love.physics.newBody(world, -300, 300)
	bounds.left.shape = love.physics.newCircleShape(400)
	bounds.left.fixture = love.physics.newFixture(bounds.left.body, bounds.left.shape)
	bounds.left.fixture:setCategory(1)
	
	bounds.right = {}
	bounds.right.body = love.physics.newBody(world, 800+300, 300)
	bounds.right.shape = love.physics.newCircleShape(400)
	bounds.right.fixture = love.physics.newFixture(bounds.right.body, bounds.right.shape)
	bounds.right.fixture:setCategory(1)
	
	-- Rectangles preventing the player from escaping
	bounds.upLine = {}
	bounds.upLine.body = love.physics.newBody(world,400,-50/2)
	bounds.upLine.shape = love.physics.newRectangleShape(800,50)
	bounds.upLine.fixture = love.physics.newFixture(bounds.upLine.body, bounds.upLine.shape)
	bounds.upLine.fixture:setCategory(1)
	
	bounds.downLine = {}
	bounds.downLine.body = love.physics.newBody(world,400,600+50/2)
	bounds.downLine.shape = love.physics.newRectangleShape(800,50)
	bounds.downLine.fixture = love.physics.newFixture(bounds.downLine.body, bounds.downLine.shape)
	bounds.downLine.fixture:setCategory(1)
	
	bounds.leftLine = {}
	bounds.leftLine.body = love.physics.newBody(world,-50/2,300)
	bounds.leftLine.shape = love.physics.newRectangleShape(50,600)
	bounds.leftLine.fixture = love.physics.newFixture(bounds.leftLine.body, bounds.leftLine.shape)
	bounds.leftLine.fixture:setCategory(1)
	
	bounds.rightLine = {}
	bounds.rightLine.body = love.physics.newBody(world, 800+50/2,300)
	bounds.rightLine.shape = love.physics.newRectangleShape(50,600)
	bounds.rightLine.fixture = love.physics.newFixture(bounds.rightLine.body, bounds.rightLine.shape)
	bounds.rightLine.fixture:setCategory(1)
	
	

	math.randomseed(os.time())
	
	player = Player.new(600,450)
	
	for i = 1, math.min(nbSpawnMax,nbSwearsMax) do
		swears[i] = Thought.new(1)
		nbSwears = nbSwears + 1
	end
	
	timeNextNonSwear = math.random()*maxTimeGame/2/(nbNonSwearsMax+1)
	
	swearOMeter = HUDBar.new(400,25,200,10,196,6,0,0,lightBlue,normalBlue,darkRed,"Swear O' Meter")
	timeLeft = HUDBar.new(400,55,200,10,196,6,maxTimeGame,maxTimeGame,lightBlue,darkBlue,white,"Time Left")
end

function love.update(dt)
	if panel == 0 then
		timeCountMessage = timeCountMessage + dt
		if (love.keyboard.isDown(" ") or love.keyboard.isDown("return")) and timeCountMessage > 1 then
			panel = 0.5
			timeCountMessage = 0
			if HardMode == 1 then
				incrementGoodAnswer = 1
				incrementBadAnswer = 3
				maxTimeConversation = 8
			else
				incrementGoodAnswer = 0.75
				incrementBadAnswer = 2
				maxTimeConversation = 12
			end
		elseif love.keyboard.isDown("up") or love.keyboard.isDown("w") or love.keyboard.isDown("down") or love.keyboard.isDown("s") then
			if keyReleased == 1 then
				keyReleased = 0
				HardMode = (HardMode + 1) % 2
			end
		else
			keyReleased = 1
		end
	elseif panel == 0.5 then
		timeCountMessage = timeCountMessage + dt
		if (love.keyboard.isDown(" ") or love.keyboard.isDown("return")) and timeCountMessage > 1 then
			panel = 1	
			timeCountMessage = 0
		end
	elseif panel == 1 then
		world:update(dt)
		player:update(dt)
		timeCountSwear = timeCountSwear + dt
		timeCountNonSwear = timeCountNonSwear + dt
		
		if timeCountSwear > delayBeforeSpawn then
			if nbSwears < nbSwearsMax then
				for i = 1, math.min(nbSpawnMax,nbSwearsMax-nbSwears) do
					swears[nbSwears+1] = Thought.new(1)
					nbSwears = nbSwears + 1
				end
			end
			timeCountSwear = 0
		end
		if timeCountNonSwear > timeNextNonSwear then
			if nbNonSwears < nbNonSwearsMax then
				nonSwears[table.getn(nonSwears)+1] = Thought.new(0)
				nbNonSwears = nbNonSwears + 1
				timeNextNonSwear = maxTimeGame/2/(nbNonSwearsMax+1)*nbNonSwears + math.random()*maxTimeGame/2/(nbNonSwearsMax+1)
			end
		end
		
		for i,currentSwear in ipairs(swears) do
			if currentSwear.alive == 1 then
				currentSwear:update(dt)
			else
				swears[i] = Thought.new(1)
			end
		end
		for i,currentNonSwear in ipairs(nonSwears) do
			if currentNonSwear.alive == 1 then
				currentNonSwear:update(dt)
			end
		end
		timeLeft:substract(dt)
		if timeLeft.filling == 0 then
			timeLeft.maxValue = maxTimeConversation
			timeLeft.filling = timeLeft.maxValue
			panel = 2
			conversation = Conversation.new(indexConversation,goodAnswersNumber,badAnswersNumber)
		end
	elseif panel == 2 then
		if timeLeft.filling ~= 0 and conversation.selected ~= 1 then
			timeLeft:substract(dt)
			conversation:update(dt)
		else
			timeLeft.maxValue = maxTimeGame
			timeLeft.filling = timeLeft.maxValue
			swearOMeter.filling = 0
			swearOMeter.maxValue = 0
			goodAnswersNumber = 0
			badAnswersNumber = 0
			timeCountNonSwear = 0
			timeCountSwear = 0
			timeCountMessage = 0
			
			nbNonSwears = 0
			for _,currentNonSwear in ipairs(nonSwears) do
				if currentNonSwear.alive == 1 then
					currentNonSwear:destroy()
				end
			end
			nbNonSwearsMax = table.getn(TextBase.dialogsNormal[indexConversation]) -1
			timeNextNonSwear = math.random()*maxTimeGame/2/(nbNonSwearsMax+1)
			
			if conversation.selected == 1 and conversation.nbAnswers > 0 then
				if conversation.answers[conversation.indexFocus][2] == 1 then
					nbSwearsMax = nbSwearsMax + incrementGoodAnswer
					swearsInARow = 0
					goodAnswerSound:play()
					panel = 4
				else
					nbSwearsMax = nbSwearsMax + incrementBadAnswer
					swearsInARow = swearsInARow + 1
					badAnswerSound:play()
					panel = 3
				end
			else
				nbSwearsMax = nbSwearsMax + incrementGoodAnswer
				swearsInARow = swearsInARow + 1
				badAnswerSound:play()
				panel = 3
			end
			
			indexConversation = indexConversation + 1
			
			if swearsInARow >= 3 then
				swearsInARow = 0
				panel = 5
			elseif indexConversation > table.getn(TextBase.dialogsNormal) then
				swearsInARow = 0
				panel = 6
			end
			
			
		end
	elseif panel == 3 then
		timeCountMessage = timeCountMessage + dt
		if timeCountMessage > maxTimeMessage or ((love.keyboard.isDown(" ") or love.keyboard.isDown("return")) and timeCountMessage > 1) then
			timeCountMessage = 0
			panel = 1
		end
	elseif panel == 4 then
		timeCountMessage = timeCountMessage + dt
		if timeCountMessage > maxTimeMessage or ((love.keyboard.isDown(" ") or love.keyboard.isDown("return")) and timeCountMessage > 1) then
			timeCountMessage = 0
			panel = 1
		end
	elseif panel == 5 or panel == 6 then
		timeCountMessage = timeCountMessage + dt
		if (love.keyboard.isDown(" ") or love.keyboard.isDown("return")) and timeCountMessage > 1 then
			timeCountMessage = 0
			panel = 0
			player:destroy()
			player = Player.new(600,450)
			for _,currentNonSwear in ipairs(nonSwears) do
				if currentNonSwear.alive == 1 then
					currentNonSwear:destroy()
				end
			end
			for _,currentSwear in ipairs(swears) do
				if currentSwear.alive == 1 then
					currentSwear:destroy()
				end
			end
			swears = {}
			nonSwears = {}
			nbSwearsMax = 2
			nbNonSwearsMax = 5
			nbSwears = 0
			nbNonSwears = 0
			swearsInARow = 0
			indexConversation = 1
			for i = 1, math.min(nbSpawnMax,nbSwearsMax) do
				swears[i] = Thought.new(1)
				nbSwears = nbSwears + 1
			end
			timeNextNonSwear = math.random()*maxTimeGame/2/(nbNonSwearsMax+1)
			swearOMeter = HUDBar.new(400,25,200,10,196,6,0,0,lightBlue,normalBlue,darkRed,"Swear O' Meter")
			timeLeft = HUDBar.new(400,55,200,10,196,6,maxTimeGame,maxTimeGame,lightBlue,darkBlue,white,"Time Left")
		end
	end
end

function love.draw()
	if panel == 0 then
		love.graphics.draw(menu,0,0)
		font = love.graphics.newFont("visitor1.ttf", 40) -- I know that it's not good to do here, but 1am.
		love.graphics.setFont(font)
		if HardMode == 1 then
			love.graphics.setColor(white)
		else
			love.graphics.setColor(lightBlue)
		end
		love.graphics.printf("Normal",200, 390, 400,"center")
		if HardMode ~= 1 then
			love.graphics.setColor(white)
		else
			love.graphics.setColor(lightBlue)
		end
		love.graphics.printf("Hard",200, 420, 400,"center")
		
		font = love.graphics.newFont("visitor1.ttf", 16)
		love.graphics.setFont(font)
	end
	if panel == 0.5 then
		love.graphics.draw(tutorial,0,0)
	end
	if panel~=0 and panel ~=0.5 then
		love.graphics.setColor(white)
		love.graphics.draw(background,0,0)
		for _,currentSwear in ipairs(swears) do
			if currentSwear.alive == 1 then
				currentSwear:draw()
			end
		end
		for _,currentNonSwear in ipairs(nonSwears) do
			if currentNonSwear.alive == 1 then
				currentNonSwear:draw()
			end
		end
		player:draw()
		love.graphics.draw(border,0,0)
	end
	if panel == 1 then
		swearOMeter:draw()
		timeLeft:draw()
		love.graphics.printf("Current dialog :",300, 510, 200,"center")
		love.graphics.printf("\"" .. TextBase.dialogsNormal[indexConversation][1] .. "\"",200, 530, 400,"center")
		if swearsInARow == 2 then
			love.graphics.setColor(red)
		end
		love.graphics.printf("Swears in a row : ".. swearsInARow,300,560,200,"center")
	end
	if panel == 2 then
		love.graphics.setColor(23,61,76,190)
		love.graphics.rectangle("fill",0,0,800,600)
		swearOMeter:draw()
		timeLeft:draw()
		conversation:draw()
	end
	if panel == 3 then
		love.graphics.setColor(23,61,76,190)
		love.graphics.rectangle("fill",0,0,800,600)
		love.graphics.setColor(white)
		love.graphics.draw(frown,0,75)
		if math.floor(timeCountMessage*2)%2 == 1 then
			love.graphics.setColor(white)
		else
			love.graphics.setColor(red)
		end
		love.graphics.printf("Wrong Answer!\n+"..incrementBadAnswer.." Swears / wave\n\nEnter or Spacebar to pass",300, 200, 200,"center")
	end
	if panel == 4 then
		love.graphics.setColor(23,61,76,190)
		love.graphics.rectangle("fill",0,0,800,600)
		love.graphics.setColor(white)
		love.graphics.draw(smile,0,75)
		if math.floor(timeCountMessage*2)%2 == 1 then
			love.graphics.setColor(white)
		else
			love.graphics.setColor(green)
		end
		love.graphics.printf("Good Answer!\n+"..incrementGoodAnswer.." Swear(s) / wave\n\nEnter or Spacebar to pass",300, 200, 200,"center")
	end
	if panel == 5 then
		love.graphics.setColor(23,61,76,190)
		love.graphics.rectangle("fill",0,0,800,600)
		love.graphics.setColor(white)
		love.graphics.draw(frown,0,75)
		love.graphics.setColor(red)
		love.graphics.printf("\"That's enough! We're not friends anymore!\"",200, 200, 400,"center")
		love.graphics.setColor(white)
		love.graphics.printf("Too bad...\nYou failed having a conversation with that guy.",200, 220, 400,"center")
		love.graphics.setColor(lightBlue)
		love.graphics.printf("Enter or Spacebar to go back to menu",200, 550, 400,"center")
	
	end
	if panel == 6 then
		love.graphics.setColor(23,61,76,190)
		love.graphics.rectangle("fill",0,0,800,600)
		love.graphics.setColor(white)
		love.graphics.draw(smile,0,75)
		love.graphics.setColor(green)
		love.graphics.printf("\"Well, I will go, then. See you!\"",200, 200, 400,"center")
		love.graphics.setColor(white)
		love.graphics.printf("Congratulations!\n You managed to have a conversation with that guy!",200, 220, 400,"center")
		love.graphics.setColor(lightBlue)
		love.graphics.printf("Enter or Spacebar to go back to menu",200, 480, 400,"center")
		love.graphics.printf("Made by Aomeas for LD29",200, 550, 400,"center")
	end
	love.graphics.setColor(white)
	if soundOn == 1 then
		love.graphics.print("Sounds : On",10,580)
	else
		love.graphics.print("Sounds : Off",10,580)
	end
end

function love.mousepressed(x, y, button)
	if button == "l" then
    	if x < 140 and y > 560 then
     		if soundOn == 1 then
     			soundOn = 0
				music:setVolume(0)
				swear_die:setVolume(0)
				swearPassed:setVolume(0)
				nonSwearPassed:setVolume(0)
				changeSelect:setVolume(0)
				badAnswerSound:setVolume(0)
				goodAnswerSound:setVolume(0)
			else
				soundOn = 1
				music:setVolume(0.4)
				swear_die:setVolume(0.6)
				swearPassed:setVolume(0.2)
				nonSwearPassed:setVolume(0.2)
				changeSelect:setVolume(0.4)
				badAnswerSound:setVolume(0.5)
				goodAnswerSound:setVolume(0.5)
			end
		end
	end
end

function love.keypressed(key)
	if key == "m" then
		if soundOn == 1 then
			soundOn = 0
			music:setVolume(0)
			swear_die:setVolume(0)
			swearPassed:setVolume(0)
			nonSwearPassed:setVolume(0)
			changeSelect:setVolume(0)
			badAnswerSound:setVolume(0)
			goodAnswerSound:setVolume(0)
		else
			soundOn = 1
			music:setVolume(0.4)
			swear_die:setVolume(0.6)
			swearPassed:setVolume(0.2)
			nonSwearPassed:setVolume(0.2)
			changeSelect:setVolume(0.4)
			badAnswerSound:setVolume(0.5)
			goodAnswerSound:setVolume(0.5)
		end
	end
end