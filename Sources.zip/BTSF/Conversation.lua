local Conversation = {
	x = 400,
	y = 180,
	question = "",
	wQuestion = 0,
	w = {},
	indexFocus = 1,
	h = 0,
	selected = 0,
	answers = nil,
	nbAnswers = 0,
	keyReleased = 1,
}
Conversation.__index = Conversation

function Conversation.new(indexConversation,nonSwearNumber,swearNumber)
	local self = setmetatable({}, Conversation)
	local font = love.graphics.getFont()
	local addedSwearNumber, addedNonSwearNumber, i, rand, rand1,rand2, randIndexNonSwear, indexNonSwear
	addedSwearNumber = 0
	addedNonSwearNumber = 0
	i = 1
	
	if nonSwearNumber + swearNumber > 25 then
		swearNumber = 25 - nonSwearNumber
	end
	
	self.h = font:getHeight()
	self.wQuestion = font:getWidth(TextBase.dialogsNormal[indexConversation][1])
	self.question = "\"" .. TextBase.dialogsNormal[indexConversation][1] .. "\""
	self.nbAnswers = nonSwearNumber + swearNumber
	self.answers = {}
	randIndexNonSwear = math.random(2,table.getn(TextBase.dialogsNormal[indexConversation]))
	
	while addedSwearNumber + addedNonSwearNumber < swearNumber + nonSwearNumber do
		if swearNumber - addedSwearNumber == 0 then
			indexNonSwear = randIndexNonSwear + addedNonSwearNumber
			if indexNonSwear > table.getn(TextBase.dialogsNormal[indexConversation]) then
				indexNonSwear = indexNonSwear - table.getn(TextBase.dialogsNormal[indexConversation]) + 1
			end
			self.w[i] = font:getWidth(TextBase.dialogsNormal[indexConversation][indexNonSwear])
			self.answers[i] = {TextBase.dialogsNormal[indexConversation][indexNonSwear],1}
			addedNonSwearNumber = addedNonSwearNumber + 1 
		elseif nonSwearNumber - addedNonSwearNumber == 0 then
			rand = math.random(1,table.getn(TextBase.swearsLines))
			self.w[i] = font:getWidth(TextBase.swearsLines[rand])
			self.answers[i] = {TextBase.swearsLines[rand],0}
			addedSwearNumber = addedSwearNumber + 1 
		else
			rand1 = math.random(1,swearNumber - addedSwearNumber)
			rand2 = math.random(1,nonSwearNumber - addedSwearNumber)
			if rand1 > rand2 then
				indexNonSwear = randIndexNonSwear + addedNonSwearNumber
				if indexNonSwear > table.getn(TextBase.dialogsNormal[indexConversation]) then
					indexNonSwear = indexNonSwear - table.getn(TextBase.dialogsNormal[indexConversation]) + 1
				end
				self.w[i] = font:getWidth(TextBase.dialogsNormal[indexConversation][indexNonSwear])
				self.answers[i] = {TextBase.dialogsNormal[indexConversation][indexNonSwear],1}
				addedNonSwearNumber = addedNonSwearNumber + 1 
			else
				rand = math.random(1,table.getn(TextBase.swearsLines))
				self.w[i] = font:getWidth(TextBase.swearsLines[rand])
				self.answers[i] = {TextBase.swearsLines[rand],0}
				addedSwearNumber = addedSwearNumber + 1
			end
		end
		i = i+1
	end
	
	return self
end

function Conversation:update(dt)
	if love.keyboard.isDown("up") or love.keyboard.isDown("w") then
		if self.keyReleased == 1 then
			self.indexFocus = self.indexFocus - 1
			if self.indexFocus < 1 then
				self.indexFocus = self.nbAnswers
			end
			self.keyReleased = 0
			changeSelect:play()
		end
	elseif love.keyboard.isDown("down") or love.keyboard.isDown("s") then
		if self.keyReleased == 1 then
			self.indexFocus = self.indexFocus + 1
			if self.indexFocus > self.nbAnswers then
				self.indexFocus = 1
			end
			self.keyReleased = 0
			changeSelect:play()
		end
	else
		self.keyReleased = 1
	end
	if love.keyboard.isDown(" ") or love.keyboard.isDown("return") then
		self.selected = 1
	end
end

function Conversation:draw()
	love.graphics.setColor(white)
	love.graphics.print(self.question,self.x-self.wQuestion/2,self.y-2*self.h)
	for i = 1,table.getn(self.answers) do
		if i == self.indexFocus then
			love.graphics.setColor(lightBlue)
		else
			love.graphics.setColor(white)
		end
		love.graphics.print(self.answers[i][1],self.x-self.w[i]/2,self.y+i*self.h)
	end
	love.graphics.setColor(white)
end

function Conversation:drawLine()
	love.graphics.setColor(white)
	love.graphics.print(self.question,self.x-self.wQuestion/2,self.y-2*self.h)
end

return Conversation